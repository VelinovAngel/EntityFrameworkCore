﻿namespace P01_StudentSystem.Data.Models
{
    public enum ContentType
    {
        //Application, Pdf or Zip
        Application = 1,
        Pdf = 2,
        Zip = 3
    }
}