﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        static IMapper mapper;
        public static void Main(string[] args)
        {
            CarDealerContext context = new CarDealerContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            string inputSuppliersFromJson = File.ReadAllText("../../../Datasets/suppliers.json");

            var resultImportSuppliers = ImportSuppliers(context, inputSuppliersFromJson);

            Console.WriteLine(resultImportSuppliers);
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var dtoSupplieres = JsonConvert.DeserializeObject<IEnumerable<SuppliersInputModel>>(inputJson);

            InitializerAutoMapper();

            var suppliers = mapper.Map<IEnumerable<Supplier>>(dtoSupplieres);

            context.AddRange(suppliers);
            context.SaveChanges();


            return $"Successfully imported {suppliers.Count()}.";
        }

        public static void InitializerAutoMapper()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<CarDealerProfile>();
            });

            mapper = config.CreateMapper();
        }
    }
}