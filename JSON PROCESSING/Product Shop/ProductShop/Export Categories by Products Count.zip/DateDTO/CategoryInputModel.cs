﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DateDTO
{
    public class CategoryInputModel
    {
        public string Name { get; set; }

    }
}
